WordloomToolkit Starter Pack
============================

已为你生成程序图标：icons/app.ico
源图：WordloomToolkit.jfif

一、图标使用（PyInstaller 打包）
------------------------------
- Windows 单文件示例：
    pyinstaller -w -F app.py -n WordloomToolkit.exe --icon=icons/app.ico --add-data "icons;icons" --add-data "config;config"

- 若程序名/入口不同，请把 app.py 替换成你的入口文件名。

二、图标使用（PySide6 运行时窗口图标）
-----------------------------------
在主窗口初始化后设置：
    app.setWindowIcon(QIcon("icons/app.ico"))

三、图标使用（Streamlit 页面图标）
--------------------------------
    st.set_page_config(page_title="Wordloom Toolkit", page_icon="icons/app.ico")

四、推荐文件布局
---------------
D:\PROJECT\WORDLOOM\
├─ tools\
│  └─ WordloomToolkit\
│     ├─ WordloomToolkit.exe
│     ├─ config\
│     │  ├─ default.yaml
│     │  └─ user.yaml
│     ├─ icons\
│     │  └─ app.ico
│     └─ （可选）ffmpeg\
├─ assets\
│  ├─ docs\
│  └─ static\
└─ （你的其他代码与数据）

五、配置说明
-----------
- config/default.yaml：默认配置（随程序发布）
- config/user.yaml：你的偏好（会覆盖默认），例如 project_root、路径前缀等

六、下一步
---------
- 将本包解压到 tools/WordloomToolkit/ 下；
- 打包或运行程序时加载 icons 与 config；
- 完成 GUI 后，支持 Tree、Fix Path、GIF 工坊三模块的一键操作。
