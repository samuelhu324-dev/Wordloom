from pathlib import Path
import subprocess, os

def write_tree_cmd(root: Path, out_file: Path) -> bool:
    try:
        cmd = ['cmd', '/c', f'tree "{root}" /f /a']
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        out_file.write_text(res.stdout, encoding='utf-8', errors='ignore')
        return True
    except Exception:
        return False

def write_tree_py(root: Path, out_file: Path, ignore=()):
    lines = []
    root = root.resolve()
    skip = set(ignore or [])
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip]
        rel = Path(dirpath).relative_to(root)
        depth = 0 if str(rel) == '.' else len(rel.parts)
        indent = '    ' * depth
        if str(rel) != '.':
            lines.append(f"{indent}{rel.name}/")
        subindent = '    ' * (depth + (0 if str(rel) == '.' else 1))
        for f in filenames:
            lines.append(f"{subindent}{f}")
    out_file.write_text('\n'.join(lines), encoding='utf-8')