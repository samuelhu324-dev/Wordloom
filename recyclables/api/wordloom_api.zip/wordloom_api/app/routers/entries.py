
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..schemas import EntryCreate, EntryOut
from ..database import get_db

# Reuse your project's repo and models
from repo import upsert_entry  # type: ignore
from models import Entry, Source  # type: ignore
from sqlalchemy import select, desc
from .auth import get_current_token

router = APIRouter(prefix="/entries", tags=["entries"])

@router.post("", response_model=EntryOut, dependencies=[Depends(get_current_token)])
def create_entry(body: EntryCreate, db: Session = Depends(get_db)):
    try:
        new_id = upsert_entry(
            entry_id=None,
            src=body.src,
            tgt=body.tgt or "",
            ls=body.ls,
            lt=body.lt,
            source_name=body.source_name,
            source_url=body.source_url,
            created_at=body.created_at
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    row = db.execute(
        select(Entry, Source.name).join(Source, isouter=True).where(Entry.id == new_id)
    ).first()
    if not row:
        raise HTTPException(status_code=404, detail="entry not found after insert")
    e, sname = row[0], row[1]
    return EntryOut(
        id=e.id, src_text=e.src_text, tgt_text=e.tgt_text,
        lang_src=e.lang_src, lang_tgt=e.lang_tgt,
        created_at=e.created_at, source_name=sname
    )

@router.get("/recent", response_model=List[EntryOut], dependencies=[Depends(get_current_token)])
def recent(limit: int = 20, db: Session = Depends(get_db)):
    limit = max(1, min(100, limit))
    rows = db.execute(
        select(Entry, Source.name).join(Source, isouter=True).order_by(desc(Entry.created_at)).limit(limit)
    ).all()
    out = []
    for row in rows:
        e, sname = row[0], row[1]
        out.append(EntryOut(
            id=e.id, src_text=e.src_text, tgt_text=e.tgt_text,
            lang_src=e.lang_src, lang_tgt=e.lang_tgt, created_at=e.created_at,
            source_name=sname
        ))
    return out
