
from fastapi import APIRouter, HTTPException, Header
from typing import Optional
import os
from ..schemas import LoginIn, TokenOut

router = APIRouter(prefix="/auth", tags=["auth"])

DEMO_USER = os.getenv("APP_USER", "admin")
DEMO_PASS = os.getenv("APP_PASS", "admin123")
DEMO_TOKEN = os.getenv("APP_TOKEN", "devtoken123")

@router.post("/login", response_model=TokenOut)
def login(body: LoginIn):
    if body.username == DEMO_USER and body.password == DEMO_PASS:
        return TokenOut(access_token=DEMO_TOKEN)
    raise HTTPException(status_code=401, detail="invalid credentials")

def get_current_token(authorization: Optional[str] = Header(default=None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="missing Authorization header")
    try:
        scheme, token = authorization.split(" ", 1)
    except Exception:
        raise HTTPException(status_code=401, detail="invalid Authorization header")
    if scheme.lower() != "bearer" or token != DEMO_TOKEN:
        raise HTTPException(status_code=401, detail="invalid token")
    return token
