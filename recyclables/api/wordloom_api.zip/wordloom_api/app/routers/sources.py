
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select, update
from typing import List
from ..schemas import SourceOut, RenameSourceIn
from ..database import get_db
from .auth import get_current_token
from models import Source, Article  # type: ignore

router = APIRouter(prefix="/sources", tags=["sources"])

@router.get("", response_model=List[SourceOut], dependencies=[Depends(get_current_token)])
def list_sources(db: Session = Depends(get_db)):
    rows = db.execute(select(Source).where(Source.name != None).order_by(Source.name.asc())).scalars().all()
    return [SourceOut(id=r.id, name=r.name) for r in rows]

@router.patch("/rename", dependencies=[Depends(get_current_token)])
def rename(body: RenameSourceIn, db: Session = Depends(get_db)):
    old, new = body.old.strip(), body.new.strip()
    if not old or not new:
        raise HTTPException(status_code=400, detail="old/new required")
    if old == new:
        return {"status": "noop"}
    try:
        db.execute(update(Source).where(Source.name == old).values(name=new))
        db.execute(update(Article).where(Article.title == old).values(title=new))
        db.commit()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"status": "ok"}
