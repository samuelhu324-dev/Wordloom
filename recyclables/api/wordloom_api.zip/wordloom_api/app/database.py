
from typing import Generator
from sqlalchemy.orm import Session
try:
    # Prefer your project's SessionLocal (so DB stays the same)
    from models import SessionLocal  # type: ignore
except Exception:
    # Fallback local engine if not importable (for isolated runs)
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    import os
    DB_URL = os.getenv("DB_URL", "sqlite:///app.db")
    engine = create_engine(DB_URL, future=True)
    SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
