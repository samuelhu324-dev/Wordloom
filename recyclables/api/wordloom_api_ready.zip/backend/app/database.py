from pathlib import Path
import sqlite3

def resolve_db_path() -> Path:
    repo_root = Path(__file__).resolve().parents[2]
    candidates = [
        repo_root / "app.db",
        repo_root / "storage" / "wordloom.db",
        repo_root / "app" / "app.db",
    ]
    for p in candidates:
        if p.exists():
            return p
    return repo_root / "app.db"

DB_PATH = resolve_db_path()

def get_conn():
    conn = sqlite3.connect(DB_PATH.as_posix(), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn
