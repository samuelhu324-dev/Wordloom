from typing import List, Dict
import sqlite3

def list_tables(conn: sqlite3.Connection) -> List[str]:
    rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;").fetchall()
    return [r[0] for r in rows]

def pragma_table_info(conn: sqlite3.Connection, table: str) -> List[Dict]:
    q = f"PRAGMA table_info({table});"
    rows = conn.execute(q).fetchall()
    return [dict(cid=r[0], name=r[1], type=r[2], notnull=r[3], dflt_value=r[4], pk=r[5]) for r in rows]

def has_id_column(conn: sqlite3.Connection, table: str) -> bool:
    info = pragma_table_info(conn, table)
    return any(c["name"].lower() == "id" for c in info)
