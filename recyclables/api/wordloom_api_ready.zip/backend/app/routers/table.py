from typing import Any, Dict, Optional
from fastapi import APIRouter, HTTPException, Query, Body
from ..database import get_conn
from ..utils.introspect import list_tables, pragma_table_info, has_id_column

router = APIRouter(prefix="/table", tags=["table"])

def ensure_table_exists(conn, name: str):
    if name not in list_tables(conn):
        raise HTTPException(status_code=404, detail=f"Table '{name}' not found.")

@router.get("/{name}")
def list_rows(
    name: str,
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    where_col: Optional[str] = None,
    where_op: Optional[str] = Query(None, pattern="^(=|!=|<|<=|>|>=|LIKE)$"),
    where_val: Optional[str] = None,
):
    with get_conn() as conn:
        ensure_table_exists(conn, name)
        cols = [c["name"] for c in pragma_table_info(conn, name)]
        col_list = ", ".join([f'"{c}"' for c in cols]) if cols else "*"
        base = f'SELECT {col_list} FROM "{name}"'
        params = []
        if where_col and where_op and where_val is not None and where_col in cols:
            base += f' WHERE "{where_col}" {where_op} ?'
            params.append(where_val)
        base += " LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = conn.execute(base, params).fetchall()
        return [dict(r) for r in rows]

@router.get("/{name}/{row_id}")
def get_one(name: str, row_id: Any):
    with get_conn() as conn:
        ensure_table_exists(conn, name)
        if not has_id_column(conn, name):
            raise HTTPException(status_code=400, detail=f"Table '{name}' has no 'id' column.")
        q = f'SELECT * FROM "{name}" WHERE id = ?'
        row = conn.execute(q, (row_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Row not found.")
        return dict(row)

@router.post("/{name}")
def insert_row(name: str, payload: Dict[str, Any] = Body(...)):
    with get_conn() as conn:
        ensure_table_exists(conn, name)
        cols = [c["name"] for c in pragma_table_info(conn, name)]
        bad = [k for k in payload.keys() if k not in cols]
        if bad:
            raise HTTPException(status_code=400, detail=f"Unknown columns: {bad}")
        if not payload:
            raise HTTPException(status_code=400, detail="Empty payload.")
        keys = ", ".join([f'"{k}"' for k in payload.keys()])
        placeholders = ", ".join(["?"] * len(payload))
        q = f'INSERT INTO "{name}" ({keys}) VALUES ({placeholders})'
        cur = conn.execute(q, tuple(payload.values()))
        conn.commit()
        return {"inserted_id": cur.lastrowid}

@router.put("/{name}/{row_id}")
def update_row(name: str, row_id: Any, payload: Dict[str, Any] = Body(...)):
    with get_conn() as conn:
        ensure_table_exists(conn, name)
        if not has_id_column(conn, name):
            raise HTTPException(status_code=400, detail=f"Table '{name}' has no 'id' column.")
        if not payload:
            raise HTTPException(status_code=400, detail="Empty payload.")
        cols = [c["name"] for c in pragma_table_info(conn, name)]
        bad = [k for k in payload.keys() if k not in cols or k.lower() == "id"]
        if bad:
            raise HTTPException(status_code=400, detail=f"Unknown/immutable columns: {bad}")
        sets = ", ".join([f'"{k}"=?' for k in payload.keys()])
        q = f'UPDATE "{name}" SET {sets} WHERE id=?'
        cur = conn.execute(q, tuple(payload.values()) + (row_id,))
        conn.commit()
        return {"updated": cur.rowcount}

@router.delete("/{name}/{row_id}")
def delete_row(name: str, row_id: Any):
    with get_conn() as conn:
        ensure_table_exists(conn, name)
        if not has_id_column(conn, name):
            raise HTTPException(status_code=400, detail=f"Table '{name}' has no 'id' column.")
        q = f'DELETE FROM "{name}" WHERE id=?'
        cur = conn.execute(q, (row_id,))
        conn.commit()
        return {"deleted": cur.rowcount}
