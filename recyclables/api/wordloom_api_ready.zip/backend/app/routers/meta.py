from fastapi import APIRouter
from ..database import DB_PATH, get_conn
from ..utils.introspect import list_tables

router = APIRouter(tags=["meta"])

@router.get("/ping")
def ping():
    return {"status": "ok"}

@router.get("/db/path")
def db_path():
    return {"db_path": str(DB_PATH)}

@router.get("/tables")
def tables():
    with get_conn() as conn:
        return {"tables": list_tables(conn)}
