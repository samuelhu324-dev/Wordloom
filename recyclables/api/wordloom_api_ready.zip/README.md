# Wordloom API (Standalone, Streamlit-independent)

This backend is a pure FastAPI service. It auto-detects your SQLite DB path:
1) `<repo root>/app.db` (recommended single source of truth)
2) `storage/wordloom.db` (fallback for your current layout)
3) `app/app.db` (legacy)

## Run
```bash
run_backend.bat
# or
python -m uvicorn backend.app.main:app --reload --host 127.0.0.1 --port 8000
```
Open: http://127.0.0.1:8000/docs
